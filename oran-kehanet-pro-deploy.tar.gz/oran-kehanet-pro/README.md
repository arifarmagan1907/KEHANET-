# ORAN KEHANET PRO

Gerçek veri kullanan, sentetik tarihçe üretmeyen Node/Express uygulaması.

## Ne yapar?
- MS 1/X/2 oranlarını implied probability'ye çevirir.
- Fixture ID varsa API-Football'dan maç, sakatlık, tahmin ve kadro verisini çeker.
- Team ID'ler verilirse son 10 maç formu ve H2H çeker.
- Poisson skor/gol dağılımı üretir.
- API-Football tahmini varsa modelle harmanlar.
- Uygulamanın kaydettiği gerçek odds snapshot'larında benzerlik arar; uydurma tarihsel maç göstermez.
- MS X AVCISI gerçek model beraberlik olasılığını ayrı gösterir.

## Kurulum
1. Node.js 20+ kur.
2. `npm install`
3. `.env.example` dosyasını `.env` olarak kopyala.
4. API-Football anahtarını `API_FOOTBALL_KEY=` içine yaz.
5. Güncel odds gerekiyorsa The Odds API anahtarını `ODDS_API_KEY=` içine yaz.
6. `npm start`
7. `http://localhost:3000`

API-Football; fixtures, lineups, injuries, predictions, H2H ve pre-match odds gibi futbol verilerini sağlıyor. API-Football'ın ücretsiz planı şu anda günlük 100 istekle sınırlı; daha yüksek kullanım için ücretli plan gerekir.

The Odds API v4 güncel odds sağlar. Gerçek tarihsel odds endpoint'i ücretli plandadır; bu yüzden uygulama ayrıca kendi snapshot arşivini tutacak şekilde tasarlanmıştır. Snapshot toplandıkça benzer oran geçmişi gerçek veriden oluşur.

## Güvenlik
API anahtarları tarayıcıya gönderilmez; sadece Node sunucusunda tutulur. `.env` dosyasını GitHub'a yükleme.

## Google/URL
Bu klasör bir Render/Railway/Fly.io gibi Node host'una deploy edilerek URL ile açılabilir. Veritabanı yerine şu an dayanıklı basit JSON snapshot deposu kullanılır; ciddi trafik ve uzun dönem backtest için PostgreSQL'e geçirilmesi önerilir.

## İnternete açma — Render

1. Bu klasörü GitHub'a yeni bir repository olarak yükle.
2. Render'da **New + → Blueprint** seç.
3. GitHub repository'sini bağla; `render.yaml` otomatik olarak Node web servisini oluşturur.
4. Render senden `API_FOOTBALL_KEY` ve gerekiyorsa `ODDS_API_KEY` ister. Anahtarları Environment Variables alanına gir.
5. Deploy tamamlanınca Render sana `https://...onrender.com` şeklinde herkese açık URL verir.
6. URL'yi Google Chrome/Safari'de açabilirsin.

Not: Bu paket şu an tek sunuculu ve JSON snapshot deposuyla çalışır. Kalıcı büyük tarihçe için PostgreSQL eklemek sonraki production adımıdır. API anahtarlarını kesinlikle frontend'e koyma.
