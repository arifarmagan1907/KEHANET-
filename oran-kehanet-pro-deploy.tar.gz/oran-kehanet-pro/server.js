import 'dotenv/config';
import express from 'express';
import fs from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const app = express();
app.use(express.json({limit:'1mb'}));
app.use(express.static(path.join(__dirname,'public')));
const PORT = process.env.PORT || 3000;
const AF = 'https://v3.football.api-sports.io';
const OA = 'https://api.the-odds-api.com/v4';
const SNAP = path.join(__dirname,'data','snapshots.json');

async function jsonFile(){ try{return JSON.parse(await fs.readFile(SNAP,'utf8'))}catch{return []} }
async function saveJson(x){await fs.writeFile(SNAP,JSON.stringify(x,null,2))}
async function af(pathname, params={}){
  if(!process.env.API_FOOTBALL_KEY) throw new Error('API_FOOTBALL_KEY eksik');
  const u=new URL(AF+pathname); for(const [k,v] of Object.entries(params)) if(v!==undefined&&v!=='') u.searchParams.set(k,v);
  const r=await fetch(u,{headers:{'x-apisports-key':process.env.API_FOOTBALL_KEY}});
  const j=await r.json(); if(!r.ok || (j.errors && Object.keys(j.errors).length)) throw new Error(JSON.stringify(j.errors||j)); return j;
}
async function oa(pathname, params={}){
  if(!process.env.ODDS_API_KEY) throw new Error('ODDS_API_KEY eksik');
  const u=new URL(OA+pathname); u.searchParams.set('apiKey',process.env.ODDS_API_KEY); for(const [k,v] of Object.entries(params)) if(v!==undefined&&v!=='') u.searchParams.set(k,v);
  const r=await fetch(u); const j=await r.json(); if(!r.ok) throw new Error(j.message||JSON.stringify(j)); return j;
}
function norm3(a){const s=a.reduce((x,y)=>x+y,0);return a.map(x=>x/s)}
function implied(o){return norm3(o.map(x=>1/Math.max(.01,Number(x))))}
function poisson(k,l){return Math.exp(-l)*Math.pow(l,k)/fact(k)}
function fact(n){let x=1;for(let i=2;i<=n;i++)x*=i;return x}
function poissonMarkets(lh,la){let h=0,d=0,a=0,over=0,btts=0,best={p:0,s:'0-0'};for(let i=0;i<=7;i++)for(let j=0;j<=7;j++){const p=poisson(i,lh)*poisson(j,la);if(i>j)h+=p;else if(i===j)d+=p;else a+=p;if(i+j>=3)over+=p;if(i>0&&j>0)btts+=p;if(p>best.p)best={p,s:`${i}-${j}`}}return {h,d,a,over,btts,score:best.s}}
function extractStats(teamStats){
 const g=teamStats?.goals?.for?.total?.home ?? 0, ga=teamStats?.goals?.against?.total?.home ?? 0;
 return {g,ga};
}
function recentForm(fixtures, teamId){
 const arr=(fixtures?.response||[]).filter(x=>x.fixture?.status?.short==='FT').slice(0,10);
 let w=0,d=0,l=0,gf=0,ga=0; for(const f of arr){const isH=f.teams.home.id===Number(teamId), a=isH?f.teams.home:f.teams.away, b=isH?f.teams.away:f.teams.home; const gf0=a.goals??0,ga0=b.goals??0;gf+=gf0;ga+=ga0;if(gf0>ga0)w++;else if(gf0===ga0)d++;else l++;}
 return {matches:arr.length,w,d,l,gf,ga,ppg:arr.length?((w*3+d)/arr.length):0};
}
function formFactor(f){if(!f||!f.matches)return 1; return 0.86 + Math.min(.28, Math.max(-.12,(f.ppg-1.5)*.10));}
function similarity(target, row){const keys=['h','x','a','over','btts'];return Math.sqrt(keys.reduce((s,k)=>s+Math.pow((target[k]??0)-(row[k]??0),2),0));}
function scoreFromResult(r){if(r.home>r.away)return 'MS 1'; if(r.home===r.away)return 'MS X'; return 'MS 2'}

app.get('/api/health',async(_q,res)=>res.json({ok:true,apiFootball:!!process.env.API_FOOTBALL_KEY,oddsApi:!!process.env.ODDS_API_KEY,snapshots:(await jsonFile()).length}));
app.get('/api/search-team',async(req,res)=>{try{const q=String(req.query.q||'').trim();if(!q)return res.json([]);const j=await af('/teams',{search:q});res.json((j.response||[]).slice(0,10).map(x=>({id:x.team.id,name:x.team.name,country:x.team.country,logo:x.team.logo})));}catch(e){res.status(400).json({error:e.message})}});
app.get('/api/fixture/:id',async(req,res)=>{try{const id=req.params.id;const [f,inj,pred,line]=await Promise.allSettled([af('/fixtures',{id}),af('/injuries',{fixture:id}),af('/predictions',{fixture:id}),af('/fixtures/lineups',{fixture:id})]);res.json({fixture:f.status==='fulfilled'?f.value.response?.[0]:null,injuries:inj.status==='fulfilled'?inj.value.response:[],prediction:pred.status==='fulfilled'?pred.value.response?.[0]:null,lineups:line.status==='fulfilled'?line.value.response:[]});}catch(e){res.status(400).json({error:e.message})}});
app.get('/api/upcoming',async(req,res)=>{try{const params={league:req.query.league,season:req.query.season,from:req.query.from,to:req.query.to,timezone:'Europe/Istanbul'};const j=await af('/fixtures',params);res.json((j.response||[]).map(f=>({id:f.fixture.id,date:f.fixture.date,status:f.fixture.status.short,home:f.teams.home,away:f.teams.away,league:f.league})));}catch(e){res.status(400).json({error:e.message})}});
app.get('/api/current-odds',async(req,res)=>{try{const j=await oa(`/sports/${encodeURIComponent(req.query.sport||process.env.ODDS_SPORT_KEY||'soccer_epl')}/odds`,{regions:req.query.regions||process.env.ODDS_REGIONS||'eu',markets:'h2h,totals',oddsFormat:'decimal'});res.json(j);}catch(e){res.status(400).json({error:e.message})}});
app.post('/api/snapshot',async(req,res)=>{try{const body=req.body||{};if(!body.fixtureId||!body.home||!body.away||!body.odds)throw new Error('fixtureId, home, away ve odds gerekli');const all=await jsonFile();const row={id:crypto.randomUUID(),capturedAt:new Date().toISOString(),...body};all.push(row);await saveJson(all);res.json({ok:true,id:row.id,total:all.length});}catch(e){res.status(400).json({error:e.message})}});
app.get('/api/similar',async(req,res)=>{try{const odds=[Number(req.query.o1),Number(req.query.ox),Number(req.query.o2)];if(odds.some(x=>!x||x<1.01))throw new Error('Geçerli MS 1/X/2 oranları gir');const [h,x,a]=implied(odds);const target={h,x,a};let rows=(await jsonFile()).filter(r=>r.odds?.o1&&r.odds?.ox&&r.odds?.o2).map(r=>({...r,dist:similarity(target,implied([r.odds.o1,r.odds.ox,r.odds.o2]))})).sort((p,q)=>p.dist-q.dist).slice(0,25);const counts={one:0,draw:0,two:0};for(const r of rows){const s=scoreFromResult(r.result||{});if(s==='MS 1')counts.one++;else if(s==='MS X')counts.draw++;else counts.two++;}res.json({count:rows.length,target,distribution:counts,rows});}catch(e){res.status(400).json({error:e.message})}});
app.get('/api/analyze',async(req,res)=>{
 try{
  const {fixtureId,homeId,awayId,league,season,o1,ox,o2,over,under,btts}=req.query;
  if([o1,ox,o2].some(x=>!x)) throw new Error('MS 1 / X / 2 oranları gerekli');
  const market=implied([+o1,+ox,+o2]);
  let fixture=null, injuries=[], prediction=null, lineups=[], homeForm=null, awayForm=null, h2h=[];
  if(fixtureId){const r=await (await fetch(`http://127.0.0.1:${PORT}/api/fixture/${fixtureId}`)).json();fixture=r.fixture;injuries=r.injuries||[];prediction=r.prediction;lineups=r.lineups||[];}
  if(homeId&&awayId){
    const [hf,afm,h2]=await Promise.all([af('/fixtures',{team:homeId,last:10,timezone:'Europe/Istanbul'}),af('/fixtures',{team:awayId,last:10,timezone:'Europe/Istanbul'}),af('/fixtures/headtohead',{h2h:`${homeId}-${awayId}`,last:10})]);
    homeForm=recentForm(hf,homeId);awayForm=recentForm(afm,awayId);h2h=h2.response||[];
  }
  const ph=prediction?.percent?.home?Number(String(prediction.percent.home).replace('%',''))/100:null;
  const px=prediction?.percent?.draw?Number(String(prediction.percent.draw).replace('%',''))/100:null;
  const pa=prediction?.percent?.away?Number(String(prediction.percent.away).replace('%',''))/100:null;
  let model=[market[0],market[1],market[2]];
  if(ph!=null&&px!=null&&pa!=null) model=norm3([market[0]*.58+ph*.42,market[1]*.58+px*.42,market[2]*.58+pa*.42]);
  if(homeForm&&awayForm){const hf=formFactor(homeForm),afac=formFactor(awayForm);model=norm3([model[0]*hf,model[1],model[2]*afac]);}
  let lh=1.35,la=1.10;if(prediction?.goals?.home)lh=Number(prediction.goals.home);if(prediction?.goals?.away)la=Number(prediction.goals.away);else {lh=1.35*formFactor(homeForm);la=1.10*formFactor(awayForm)}
  const pois=poissonMarkets(lh,la);
  model=norm3([model[0]*.72+pois.h*.28,model[1]*.72+pois.d*.28,model[2]*.72+pois.a*.28]);
  const sim=await (await fetch(`http://127.0.0.1:${PORT}/api/similar?o1=${o1}&ox=${ox}&o2=${o2}`)).json();
  if(sim.count>=5){const s=sim.distribution,total=s.one+s.draw+s.two;model=norm3([model[0]*.78+(s.one/total)*.22,model[1]*.78+(s.draw/total)*.22,model[2]*.78+(s.two/total)*.22]);}
  const picks=['MS 1','MS X','MS 2'];const max=Math.max(...model),pick=picks[model.indexOf(max)];
  const xChance= model[1]; const confidence=Math.round(Math.min(96,52+Math.abs(max-.333)*120+(sim.count>=10?8:0)));
  res.json({ok:true,fixture,injuries,prediction,lineups,homeForm,awayForm,h2h,market,model,selection:pick,confidence,score:pois.score,goals:{home:lh,away:la},over25:over&&under?implied([+over,+under])[0]:pois.over,btts:btts?implied([+btts,+(req.query.bttsNo||1.9)])[0]:pois.btts,similar:sim,drawHunter:{score:Math.round(xChance*100),label:xChance>=.34?'GÜÇLÜ ADAY':xChance>=.30?'İZLE':'ZAYIF'}});
 }catch(e){res.status(400).json({error:e.message})}
});

app.use((_req,res)=>res.sendFile(path.join(__dirname,'public','index.html')));
app.listen(PORT,()=>console.log(`ORAN KEHANET PRO http://localhost:${PORT}`));
